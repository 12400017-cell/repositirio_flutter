import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';
import 'package:leonardo_melo/pages/teleInicial.dart';
void main() {

  runApp(
    DevicePreview(
      builder: (context) {
        return MyApp();
      }
    )
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Central de Expedições Espaciais',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const TelaInicial()
    );
  }
}
